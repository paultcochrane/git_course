// hallo: ein Programm um "hallo!" zu sagen
#include <stdio.h>

int main(void) {
    printf("Hallo, Welt!\n");
    return(0);
}
